# @sonygrg/nepali-datepicker

A Nepali (Bikram Sambat) date picker component for React, built with MUI.

## Installation

Install the package:

```bash
npm install @sonygrg/nepali-datepicker
```

This package requires the following dependencies:

```bash
npm install react react-dom @mui/material @mui/x-date-pickers @emotion/react @emotion/styled
```

## Usage

```tsx
import { InputCalendar } from "@sonygrg/nepali-datepicker";

function App() {
  return <InputCalendar />;
}

export default App;
```

## Features

- Type a Nepali date manually (e.g. `२०८३/०१/०१`), or pick it from a calendar grid
- Displays dates in Nepali digits

## License

MIT
